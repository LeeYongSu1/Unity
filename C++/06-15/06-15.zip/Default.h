#pragma once
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;
