#pragma once
#include <iostream>
#include <cstring>
#include <cstdlib>

using namespace std;